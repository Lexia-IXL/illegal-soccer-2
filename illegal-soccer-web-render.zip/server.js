const express = require("express");
const http = require("http");
const path = require("path");
const { WebSocketServer } = require("ws");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

const PORT = process.env.PORT || 10000;
const W = 1800, H = 1000;
const GOAL_Y = 330, GOAL_H = 340;
const TICK = 1000 / 30;
const MAX_PLAYERS = 8;
const MIN_HUMANS = 2;
const BOT_FILL_DELAY = 3500;

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_, res) => res.json({ ok: true, players: humans().length, bots: bots().length }));

const players = new Map();
let nextId = 1;
let score = [0, 0];
let round = 1;
let roundClock = 180;
let lastBotFill = Date.now();

const powerTypes = ["speed", "superkick", "giantball", "shield"];
let powerups = [];
let ball = { x: W/2, y: H/2, vx: 0, vy: 0, owner: null, lastTouch: null };

function humans() { return [...players.values()].filter(p => !p.bot); }
function bots() { return [...players.values()].filter(p => p.bot); }
function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }
function dist(a,b){ return Math.hypot(a.x-b.x,a.y-b.y); }
function teamX(team){ return team === 0 ? 330 : W-330; }

function makePlayer(ws, bot=false) {
  const id = String(nextId++);
  const team = [...players.values()].filter(p => p.team === 0).length <= [...players.values()].filter(p => p.team === 1).length ? 0 : 1;
  const p = {
    id, ws, bot, name: bot ? `Bot ${id}` : `Player ${id}`,
    team, x: team === 0 ? 360 : W-360, y: H/2,
    vx: 0, vy: 0, facing: team === 0 ? 1 : -1,
    sprint: false, dribble: false, input: {},
    cooldown: 0, tackleUntil: 0, power: null, powerUntil: 0,
    request: false
  };
  players.set(id,p);
  return p;
}

function send(ws,msg){ if(ws && ws.readyState === 1) ws.send(JSON.stringify(msg)); }
function broadcast(msg){
  const s = JSON.stringify(msg);
  for(const p of players.values()) if(!p.bot && p.ws.readyState===1) p.ws.send(s);
}

function spawnPowerup() {
  const type = powerTypes[Math.floor(Math.random()*powerTypes.length)];
  powerups.push({ id: Math.random().toString(36).slice(2), type,
    x: 250 + Math.random()*(W-500), y: 170 + Math.random()*(H-340) });
}

function resetBall(teamScored = null) {
  ball = { x: W/2, y: H/2, vx: teamScored === null ? 0 : (teamScored===0 ? 180 : -180), vy: 0, owner:null, lastTouch:null };
  for(const p of players.values()) {
    p.x = p.team===0 ? 360 : W-360;
    p.y = H/2 + (Math.random()-0.5)*250;
    p.cooldown = 0;
  }
}

function useAction(p, action) {
  const now = Date.now();
  if(p.cooldown > now) return;

  if(action === "kick" || action === "pass" || action === "flick" || action === "lob") {
    if(dist(p,ball) < 105 || ball.owner === p.id) {
      ball.owner = null; ball.lastTouch = p.id;
      const angle = Math.atan2(ball.y-p.y, ball.x-p.x);
      let power = action === "kick" ? 820 : action === "pass" ? 520 : action === "flick" ? 650 : 480;
      if(p.power === "superkick" && p.powerUntil > now && action === "kick") power *= 1.7;
      if(action === "flick" || action === "lob") ball.vy += (p.team===0 ? -1 : 1) * 140;
      ball.vx = Math.cos(angle) * power + p.facing * 100;
      ball.vy += Math.sin(angle) * power;
      p.cooldown = now + 300;
    }
  } else if(action === "tackle") {
    p.tackleUntil = now + 260;
    p.cooldown = now + 650;
    for(const q of players.values()) {
      if(q.id!==p.id && q.team!==p.team && dist(p,q)<85) {
        q.vx += p.facing*380;
        q.vy += (Math.random()-0.5)*300;
        if(ball.owner===q.id) ball.owner=null;
      }
    }
  }
}

wss.on("connection",(ws)=>{
  const p = makePlayer(ws);
  send(ws,{type:"welcome", id:p.id, world:{W,H}, controls:{
    move:"WASD", kick:"Mouse Left", pass:"Mouse Right", flick:"Q", tackle:"E",
    lob:"F", request:"R", dribble:"Space", sprint:"Shift"
  }});
  broadcast({type:"notice",text:`${p.name} joined the match.`});

  ws.on("message",(raw)=>{
    try {
      const m=JSON.parse(raw);
      if(m.type==="input"){
        p.input=m.input||{};
        if(typeof m.name==="string" && m.name.trim()) p.name=m.name.trim().slice(0,18);
      }
      if(m.type==="action") useAction(p,m.action);
      if(m.type==="request") p.request=true;
      if(m.type==="ping") send(ws,{type:"pong",t:m.t});
    } catch {}
  });
  ws.on("close",()=>{
    players.delete(p.id);
    broadcast({type:"notice",text:`${p.name} left the match.`});
  });
});

function updateBot(p,dt){
  const target = ball.owner && players.get(ball.owner) ? players.get(ball.owner) : ball;
  const dx=target.x-p.x, dy=target.y-p.y;
  p.facing = dx>=0?1:-1;
  const len=Math.hypot(dx,dy)||1;
  p.input={up:dy/len,down:-dy/len,left:-dx/len,right:dx/len,sprint:true,dribble:true};
  if(dist(p,ball)<85 && !ball.owner) useAction(p,"kick");
  if(ball.owner && ball.owner!==p.id && players.get(ball.owner)?.team!==p.team && dist(p,players.get(ball.owner))<75) useAction(p,"tackle");
}

function physics(){
  const dt=TICK/1000;
  const now=Date.now();

  if(now-lastBotFill > BOT_FILL_DELAY){
    lastBotFill=now;
    const h=humans().length;
    const desired=Math.max(MIN_HUMANS, Math.min(MAX_PLAYERS, h));
    while(players.size < desired) makePlayer(null,true);
    // Keep a full match feel after a short wait, but never add bots if all 8 slots are human.
    if(h>0 && players.size<MAX_PLAYERS && roundClock<170){
      while(players.size<MAX_PLAYERS && humans().length<MAX_PLAYERS-2) makePlayer(null,true);
    }
  }

  for(const p of players.values()){
    if(p.bot) updateBot(p,dt);
    const i=p.input||{};
    let ax=(i.right?1:0)-(i.left?1:0), ay=(i.down?1:0)-(i.up?1:0);
    const len=Math.hypot(ax,ay)||1; ax/=len; ay/=len;
    const sprint=!!i.sprint;
    let speed=sprint?420:300;
    if(p.dribble) speed*=0.72;
    if(p.power==="speed" && p.powerUntil>now) speed*=1.45;
    p.vx += ax*speed*7*dt; p.vy += ay*speed*7*dt;
    const max=speed;
    const sp=Math.hypot(p.vx,p.vy);
    if(sp>max){p.vx=p.vx/sp*max;p.vy=p.vy/sp*max;}
    p.vx*=0.84; p.vy*=0.84;
    p.x=clamp(p.x+p.vx*dt,70,W-70); p.y=clamp(p.y+p.vy*dt,70,H-70);
    if(Math.abs(p.vx)>10) p.facing=p.vx>0?1:-1;
    if(ball.owner===p.id){
      ball.x=p.x+p.facing*48; ball.y=p.y;
    } else if(!ball.owner && dist(p,ball)<62){
      ball.owner=p.id; ball.lastTouch=p.id;
    }
    if(p.tackleUntil<now) p.tackleUntil=0;
  }

  if(!ball.owner){
    ball.x+=ball.vx*dt; ball.y+=ball.vy*dt;
    ball.vx*=0.992; ball.vy*=0.992;
    if(ball.y<35||ball.y>H-35){ball.vy*=-0.78;ball.y=clamp(ball.y,35,H-35);}
    // goals
    if(ball.x<0 && ball.y>GOAL_Y && ball.y<GOAL_Y+GOAL_H){
      score[1]++; roundClock=180; resetBall(1);
    } else if(ball.x>W && ball.y>GOAL_Y && ball.y<GOAL_Y+GOAL_H){
      score[0]++; roundClock=180; resetBall(0);
    } else if(ball.x<35||ball.x>W-35){ball.vx*=-0.78;ball.x=clamp(ball.x,35,W-35);}
  }

  for(let i=powerups.length-1;i>=0;i--){
    for(const p of players.values()){
      if(dist(p,powerups[i])<45){
        const pu=powerups[i]; p.power=pu.type; p.powerUntil=now+9000;
        powerups.splice(i,1); break;
      }
    }
  }

  if(powerups.length<3 && Math.random()<0.004) spawnPowerup();
  roundClock-=dt;
  if(roundClock<=0){round++;score=[0,0];roundClock=180;resetBall();}
}

setInterval(()=>{
  physics();
  const snapshot={
    type:"state", world:{W,H}, score, round, time:Math.max(0,Math.ceil(roundClock)),
    ball:{x:ball.x,y:ball.y,vx:ball.vx,vy:ball.vy,owner:ball.owner},
    powerups,
    players:[...players.values()].map(p=>({
      id:p.id,name:p.name,bot:p.bot,team:p.team,x:p.x,y:p.y,
      vx:p.vx,vy:p.vy,facing:p.facing,power:p.power,
      powerActive:p.powerUntil>Date.now(),tackle:!!p.tackleUntil
    }))
  };
  broadcast(snapshot);
},TICK);

server.listen(PORT,"0.0.0.0",()=>console.log(`Server listening on ${PORT}`));
