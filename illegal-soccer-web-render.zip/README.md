# Illegal Soccer Web — browser multiplayer starter

This is an original browser soccer game inspired by chaotic soccer gameplay. It does not copy Roblox assets or source code.

## Run locally
1. Install Node.js 20+.
2. In this folder run `npm install`.
3. Run `npm start`.
4. Open http://localhost:10000 in two browser windows to test multiplayer.

## Deploy to Render
Use a Render **Web Service**, not a Static Site, because the game uses a Node.js server and WebSockets.
- Build Command: `npm install`
- Start Command: `npm start`
- Branch: `main`

Render Web Services support WebSockets. The server binds to `0.0.0.0` and uses Render's `PORT` variable.

## Controls
WASD = move
Shift = sprint
Left mouse = kick
Right mouse = pass
Q = flick
E = tackle
F = lob
R = request
Space = dribble

Power-ups: Speed, Super Kick, Giant Ball, Shield.
