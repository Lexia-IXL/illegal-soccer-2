const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
let dpr=Math.min(devicePixelRatio||1,2), me=null, state=null, socket=null, keys={};
let mouse={x:0,y:0}, noticeTimer=0;

function resize(){canvas.width=innerWidth*dpr;canvas.height=innerHeight*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}
addEventListener("resize",resize);resize();

function connect(){
  const proto=location.protocol==="https:"?"wss":"ws";
  socket=new WebSocket(`${proto}://${location.host}/ws`);
  socket.onmessage=e=>{
    const m=JSON.parse(e.data);
    if(m.type==="welcome"){me=m.id; show("hud");}
    if(m.type==="state"){state=m;}
    if(m.type==="notice"){notice(m.text)}
  };
  socket.onclose=()=>{notice("Connection lost — reconnecting...");setTimeout(connect,1500)};
}
function show(id){document.querySelectorAll("#menu,#hud").forEach(x=>x.classList.add("hidden"));document.getElementById(id).classList.remove("hidden")}
function notice(t){document.getElementById("notice").textContent=t;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>document.getElementById("notice").textContent="",2500)}
document.getElementById("play").onclick=()=>{
  const n=document.getElementById("name").value.trim();
  localStorage.setItem("soccerName",n||"Player");
  connect();
};
document.getElementById("name").value=localStorage.getItem("soccerName")||"";

addEventListener("keydown",e=>{
  keys[e.code]=true;
  if(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.code))e.preventDefault();
  if(!socket||socket.readyState!==1)return;
  const map={KeyQ:"flick",KeyE:"tackle",KeyF:"lob",KeyR:"request"};
  if(map[e.code]&&!e.repeat) socket.send(JSON.stringify({type:"action",action:map[e.code]}));
});
addEventListener("keyup",e=>keys[e.code]=false);
canvas.addEventListener("mousedown",e=>{
  if(!socket||socket.readyState!==1)return;
  socket.send(JSON.stringify({type:"action",action:e.button===0?"kick":"pass"}));
});
canvas.addEventListener("contextmenu",e=>e.preventDefault());

setInterval(()=>{
  if(!socket||socket.readyState!==1)return;
  socket.send(JSON.stringify({type:"input",name:localStorage.getItem("soccerName")||"Player",input:{
    up:keys.KeyW||keys.ArrowUp,down:keys.KeyS||keys.ArrowDown,left:keys.KeyA||keys.ArrowLeft,right:keys.KeyD||keys.ArrowRight,
    sprint:keys.ShiftLeft||keys.ShiftRight,dribble:keys.Space
  }}));
},50);

function worldToScreen(x,y,scale,ox,oy){return [x*scale+ox,y*scale+oy]}
function draw(){
  requestAnimationFrame(draw);
  if(!state){ctx.fillStyle="#07120d";ctx.fillRect(0,0,innerWidth,innerHeight);return}
  const scale=Math.min((innerWidth-30)/state.world.W,(innerHeight-120)/state.world.H);
  const ox=(innerWidth-state.world.W*scale)/2, oy=(innerHeight-state.world.H*scale)/2+10;
  ctx.fillStyle="#0b2516";ctx.fillRect(0,0,innerWidth,innerHeight);

  // pitch
  ctx.fillStyle="#20703c";ctx.fillRect(ox,oy,state.world.W*scale,state.world.H*scale);
  ctx.strokeStyle="#ffffffaa";ctx.lineWidth=3;
  ctx.strokeRect(ox,oy,state.world.W*scale,state.world.H*scale);
  ctx.beginPath();ctx.moveTo(ox+state.world.W*scale/2,oy);ctx.lineTo(ox+state.world.W*scale/2,oy+state.world.H*scale);ctx.stroke();
  ctx.beginPath();ctx.arc(ox+state.world.W*scale/2,oy+state.world.H*scale/2,125*scale,0,Math.PI*2);ctx.stroke();
  ctx.strokeRect(ox,oy+(state.world.H/2-170)*scale,120*scale,340*scale);
  ctx.strokeRect(ox+(state.world.W-120)*scale,oy+(state.world.H/2-170)*scale,120*scale,340*scale);

  // goals
  ctx.fillStyle="#dfe8ea";ctx.fillRect(ox-18,oy+330*scale,18,340*scale);ctx.fillRect(ox+state.world.W*scale,oy+330*scale,18,340*scale);

  for(const pu of state.powerups){
    const [x,y]=worldToScreen(pu.x,pu.y,scale,ox,oy);
    const labels={speed:"⚡",superkick:"★",giantball:"●",shield:"◆"};
    ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(x,y,18,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#111";ctx.font="bold 17px Arial";ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillText(labels[pu.type]||"?",x,y);
  }

  for(const p of state.players){
    const [x,y]=worldToScreen(p.x,p.y,scale,ox,oy);
    ctx.save();
    ctx.translate(x,y);
    ctx.fillStyle=p.team===0?"#42a5ff":"#ff4d5d";
    ctx.beginPath();ctx.arc(0,0,24,0,Math.PI*2);ctx.fill();
    if(p.id===me){ctx.strokeStyle="#fff";ctx.lineWidth=4;ctx.beginPath();ctx.arc(0,0,29,0,Math.PI*2);ctx.stroke();}
    if(p.powerActive){ctx.strokeStyle="#ffe66d";ctx.lineWidth=4;ctx.beginPath();ctx.arc(0,0,34,0,Math.PI*2);ctx.stroke();}
    ctx.fillStyle="#fff";ctx.font="bold 12px Arial";ctx.textAlign="center";ctx.fillText(p.bot?"BOT":p.name,0,-38);
    ctx.restore();
  }
  const [bx,by]=worldToScreen(state.ball.x,state.ball.y,scale,ox,oy);
  ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(bx,by,11,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle="#111";ctx.lineWidth=2;ctx.stroke();

  const p=state.players.find(x=>x.id===me);
  document.getElementById("score").textContent=`BLUE ${state.score[0]} — ${state.score[1]} RED`;
  const mins=Math.floor(state.time/60),secs=String(state.time%60).padStart(2,"0");
  document.getElementById("timer").textContent=`${mins}:${secs}`;
  document.getElementById("players").textContent=`Players: ${state.players.filter(x=>!x.bot).length} · Bots: ${state.players.filter(x=>x.bot).length}`;
  document.getElementById("power").textContent=`POWER: ${p?.powerActive?(p.power||"").toUpperCase():"NONE"}`;
}
draw();
